angular.module('app')
    .controller('HomeController', function () {
        this.technologies = ['jQuery', 'AngularJS', 'Compass'];
    });
